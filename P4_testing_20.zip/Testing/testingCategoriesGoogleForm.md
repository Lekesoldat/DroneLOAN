### What will we ask the user to test?

1. Design

-  How pleasing is the apperance?
-  How does the design contribute towards accessibility

2. Functionality

- What did you like?
- What did you not like?

1. Accessibility 

- How easy accessible is the different pages
- Did ever require more than three clicks to get to your desitination?

4. Performance, reliability and bugs

- Was there any part of the website which was loading too slowly, if so which one?
- Did you encounter any bugs, if so where and what did you do?

5. New ideas/changes
   
- Is there anything you would like to be change or added to the website?

6. Comments

- Any other comments?
